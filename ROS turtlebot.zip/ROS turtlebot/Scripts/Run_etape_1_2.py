#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#Importation des modules necessaires
import rospy
from geometry_msgs.msg import Twist, Point
from std_msgs.msg import Float64


class ControlNode(object): #Création de la classe ControlNode.
    def __init__(self): #Definition du constructeur de la classe.
        #definition des variables que l'on va utiliser
        self.cX = None 
        self.cY = None
        self.compte = 0

        # Subscribers
        rospy.Subscriber("point_coordinates", Point, self.callback)
        rospy.Subscriber("/compte", Float64, self.callback3)

        # Publishers
        self.pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

    def callback(self, msg):
        self.cX = msg.x #Récuperation des coordonées des lignes publiées dans le code Image_challenge1.py
        self.cY = msg.y
    
    def callback3(self, msg):
        self.compte = msg.data #Recuperation du compte de lignes rouge faite dans le code Image_challenge1.py
        
    def start(self):
        rospy.loginfo("Starting control node")
        rate = rospy.Rate(10) # création d'un objet Rate pour contrôler la fréquence d'exécution de la boucle principale
        cmd_vel = Twist() # création d'un objet Twist pour stocker les commandes de vitesse linéaire et angulaire
        while not rospy.is_shutdown():  # tant que le nœud ROS n'a pas reçu de commande d'arrêt
           
            if self.cX is not None and self.cY is not None : # si l'objet est détecté
                
                if self.cX < 150:# si l'objet est trop à gauche
                    cmd_vel.angular.z = 1 # tourner à droite
                elif self.cX > 165 : # si l'objet est trop à droite
                    cmd_vel.angular.z = -1# tourner à gauche
                else:
                    cmd_vel.linear.x = 0.1 # avancer tout droit
                    cmd_vel.angular.z = 0 # ne pas tourner
            else:
                cmd_vel.linear.x = 0.1 # avancer tout droit
                cmd_vel.angular.z = 0 # ne pas tourner

            self.pub_cmd_vel.publish(cmd_vel)  # publier les commandes de vitesse linéaire et angulaire sur le topic /cmd_vel
                
            if self.compte >3: #Si 3 lignes rouges sont passées
               
                rospy.signal_shutdown('Shutdown message')  # envoyer une commande d'arrêt avec un message indiquant la raison de l'arrêt

            rate.sleep() # attendre le temps nécessaire pour maintenir la fréquence d'exécution de la boucle principale

if __name__ == '__main__':
    rospy.init_node("RUN")
    my_node = ControlNode()
    my_node.start()

