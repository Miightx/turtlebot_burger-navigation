#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from geometry_msgs.msg import Twist, Point, Pose
from std_msgs.msg import String, Float64
from nav_msgs.msg import Odometry
import math


class ControlNode(object):

  def __init__(self):
    # Params
    self.cX = None
    self.cY = None
    self.S = None
    self.compte = 0
    self.c = 0

    # Subscribers
    rospy.Subscriber("point_coor", Point, self.callback)
    rospy.Subscriber("S", Float64, self.callback1)
    rospy.Subscriber("/compte", Float64, self.callback3)

    # Publishers
    self.pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

  def callback(self, msg):
    self.cX = msg.x
    self.cY = msg.y

  def callback1(self, msg):
    self.S = msg.data

  def callback3(self, msg):
    self.compte = msg.data

  def start(self):
      
    #Initialisation
    cmd_vel = Twist() #Creer un objet Twist()
    rate = rospy.Rate(10)#Frequence d'execution
    c = 0 
    
    while not rospy.is_shutdown(): # tant que le node n'est pas arreté
        
      if self.compte>3: #Si il y a plus de 3 lignes rouges detectées
          if self.cX is not None and self.cY is not None: #Si il detecte du vert
              
            if self.cX < 130:  # Point too much on the left 
              cmd_vel.angular.z = 0.5 #Tourne 
              cmd_vel.linear.x = 0.1 #avance
             
            elif self.cX > 145:  # Point too much on the right
              cmd_vel.angular.z = -0.7 #TOurne
              cmd_vel.linear.x = 0.1  #Avance
    
            else: #Sinon  
              cmd_vel.linear.x = 0.1 #avance tout droit 
              
          self.pub_cmd_vel.publish(cmd_vel) #Publie
    
          if self.S is not None and self.S == 1: #SI il il y a un obstacle
            c += 1 #on compte le nombre d'obstacle
            if c < 2: #SI le nombre d'obstacle est inferieur a 2:
    
              cmd_vel.angular.z = 1  # Set the angular velocity to 1 to make the robot turn 90 degrees
              cmd_vel.linear.x = 0.0  # Set the linear velocity to 0.0 to prevent the robot from moving forward
              self.pub_cmd_vel.publish(cmd_vel)#publie 
              rospy.sleep(1.9)#Attend 1.9 secondes
    
              cmd_vel.angular.z = 0.0  # Stop turning
              cmd_vel.linear.x = 0.1#avance
              self.pub_cmd_vel.publish(cmd_vel)#publie
              rospy.sleep(5.6) #Attend 5.6 secondes
              cmd_vel.angular.z =- 1  # Tourne
              self.pub_cmd_vel.publish(cmd_vel) #Publie
              rospy.sleep(1) #Attends 1 seconde
              
            if c > 2:#SI le nombre d'obstacle est superieur a 2:
                
              cmd_vel.angular.z = 1  # Set the angular velocity to 1 to make the robot turn 90 degrees
              cmd_vel.linear.x = 0.0  # Set the linear velocity to 0.0 to prevent the robot from moving forward
              self.pub_cmd_vel.publish(cmd_vel) #Publie
              rospy.sleep(0.5)#Attend 0.5 seconde
    
              cmd_vel.angular.z = 0.0  # Stop turning
              self.pub_cmd_vel.publish(cmd_vel) #Publie
    
          else:#Sinon
           
            cmd_vel.linear.x = 0.1  # Va tout droit 
            self.pub_cmd_vel.publish(cmd_vel)#Publie

      rate.sleep() #Permet de respecter la frequence d'execution


if __name__ == '__main__':
  rospy.init_node("Convert")
  my_node = ControlNode()
  my_node.start()