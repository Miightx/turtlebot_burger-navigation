#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Library
import rospy
import math
from std_msgs.msg import Float64
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Twist, Point, Pose
import numpy as np


class Corridor(object):

  def __init__(self):
    # Params
    self.desired_distance = 0.24  # in meters
    self.compte = 0
    self.cX = None
    self.cY=None
    self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    self.sub = rospy.Subscriber('/scan', LaserScan, self.callback)
    
    rospy.Subscriber("point_coordinates", Point, self.callback2)
    rospy.Subscriber('/compte', Float64, self.callback1)
    self.ranges = []

  def callback(self, msg):  # Callback function
    self.ranges = msg.ranges

  def callback1(self, msg):  # Callback function
    self.compte = msg.data
    
  def callback2(self, msg):  # Callback function
    self.cX = msg.x
    self.cY = msg.y

  def start(self):
        twist = Twist()
        rate = rospy.Rate(10)   # création d'un objet Rate pour contrôler la fréquence d'exécution de la boucle principale
        rospy.sleep(5) # attendre 5 secondes avant de commencer la boucle principale
        while not rospy.is_shutdown(): # tant que le nœud ROS n'a pas reçu de commande d'arrêt
            
            # Obtenir les valeurs de distance laser à droite du robot pour le couloir
            right_ranges = self.ranges[40:70]  # sélectionner les valeurs de distance laser correspondant à l'angle de vue du capteur sur la droite du robot
            right_ranges = [v for v in right_ranges if not math.isnan(v) and not math.isinf(v)] # filtrer les valeurs invalides (nan et inf) de la liste
            if not right_ranges: # si la liste est vide
              right_ranges = 1  # fixer une distance arbitraire de 1 mètre
    
            right_range = float(np.mean(right_ranges)) # calculer la distance moyenne du mur sur la droite
            if right_range > self.desired_distance:  # si la distance mesurée est supérieure à la distance désirée
              twist.linear.x = 0.2 # avancer le robot
              twist.angular.z = 0.0 # ne pas tourner
    
            else:  # si la distance mesurée est inférieure ou égale à la distance désirée
              twist.linear.x = 0.035 # ralentir le robot
              twist.angular.z = -0.25 # tourner vers la droite
    
            self.pub.publish(twist) # publier la commande de mouvement sur le topic /cmd_vel
            
            if self.cX is not None: #Si il detecte une ligne blanche
                rospy.signal_shutdown('Shutdown message') # envoyer un message d'arrêt pour demander l'arrêt de l'exécution du nœud ROS car on est plus dans le corridor

            rate.sleep() # attendre le temps nécessaire pour maintenir la fréquence d'exécution de la boucle principale


if __name__ == '__main__':
  rospy.init_node('Corridor')
  my_node = Corridor()
  my_node.start()

