#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float64


class CNodo(object):

  def __init__(self):
    # Params
    self.obs_f = None
    self.obs_l = None
    self.message = None
    self.compte = None

    # Subscribers
    rospy.Subscriber("/scan", LaserScan, self.callback)
    rospy.Subscriber("/compte", Float64, self.callback1)

    # Publishers
    self.p = rospy.Publisher('S', Float64, queue_size=10)

  def callback(self, msg):
      #Recupere les données du laser a une certaine orientation 
    self.obs_f = msg.ranges[335:360]
    self.obs_l = msg.ranges[0:20]
    self.message = self.obs_f + self.obs_l

  def callback1(self, msg):
    self.compte = msg.data #Recupere le nombre de ligne rouge detectées

  def start(self):
    rospy.loginfo("Starting control node")
    rate = rospy.Rate(10) #Frequence d'execution
    while not rospy.is_shutdown():#Tant que le node n'est pas shutdown
      S = 0 #S prends la valeur 0: il n'y a pas d'obstacle
      if self.message is not None: #if le laser capte des objets
        for distance in self.message:
          if distance < 0.2: #SI les objets sont plus proches que 0.2
            S = 1 #S=1: il y a un objet devant
            break #On casse la boucle
      self.p.publish(S) #On publie dans le topic S

      rate.sleep()#Permet de respecter la fréquence


if __name__ == '__main__':
  rospy.init_node("Obstacle")
  my_node = CNodo()
  my_node.start()