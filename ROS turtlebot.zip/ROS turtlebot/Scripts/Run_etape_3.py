#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from geometry_msgs.msg import Twist, Point, Pose
from std_msgs.msg import String, Float64
from nav_msgs.msg import Odometry
import math


class ControlNode(object):

  def __init__(self):
    # Params
    self.cX = None
    self.cY = None
    self.cXJ = None
    self.cYJ = None
    self.S = None
    self.x = 0
    self.r=0
    self.compte = 0
    self.c = 0
    self.d = None
    self.orientation_z = None
    
    # Subscribers
    rospy.Subscriber("point_coordinates", Point, self.callback)
    rospy.Subscriber("S", Float64, self.callback1)
    rospy.Subscriber("/compte", Float64, self.callback3)
    rospy.Subscriber("/odom", Odometry, self.odom_callback)
    rospy.Subscriber("point", Point, self.callback10)

    # Publishers
    self.pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    self.pub_ob = rospy.Publisher('/obstacle', Float64, queue_size=10)

  def callback(self, msg):
    self.cX = msg.x #Recupere les coordonées des lignes blanches
    self.cY = msg.y

  def callback10(self, msg):
    self.cXJ = msg.x #Récupere les coordonnées du moment des lignes jaunes
    self.cYJ = msg.y

  def callback1(self, msg):
    self.S = msg.data #Recupere les donnees pour savoir si u  obstacle est detecté ou pas 

  def callback3(self, msg):
    self.compte = msg.data #Recupere les données du compte de lignes rouge

  def odom_callback(self, msg):
    pose = msg.pose.pose
    self.orientation_z = pose.orientation.z #Recupere les données d'orientation

  def start(self):
    cmd_vel = Twist() # Initialisation de la commande de mouvement
    rate = rospy.Rate(10) #Frequence d'execution
    while not rospy.is_shutdown(): #Tant que le node n'est pas arreté
        
       # Vérifier l'orientation du robot
        if self.orientation_z is not None and (self.orientation_z) < 0.01:
            self.d = 1 # Si le robot est orienté à gauche, définir d comme 1
        elif self.orientation_z is not None and (self.orientation_z) > 0.99:
            self.d = 0 # Si le robot est orienté à droite, définir d comme 0
        else:
            self.d = 2 #sinon d=2


        if self.compte > 1: #Si le nombre de ligne rouge >1
    # Si l'objet est détecté, tourner le robot pour qu'il soit centré sur l'objet
            if self.cX is not None and self.cY is not None:
              if self.cX < 140: # Si le robot est trop à gauche, tourner à droite
                cmd_vel.angular.z = 1
    
              elif self.cX > 170:  # Si l'objet est trop à droite, tourner à gauche
                cmd_vel.angular.z = -1
              
    
              else:# Si l'objet est centré, avancer en ligne droite
                cmd_vel.linear.x = 0.1
                cmd_vel.angular.z = 0
                
              self.pub_cmd_vel.publish(cmd_vel) # Publier la commande de mouvement
    
              if self.d == 0 and self.r == 0:#Si le robot est orienté a gauche et que c'est la 1e fois 
    
                cmd_vel.linear.x = 0.15 
                cmd_vel.angular.z = -0.2
                self.pub_cmd_vel.publish(cmd_vel) #On commande le robot pour qu'il aille ou on veut puis on publie
                self.r = 1 #self.r prend la valeur 1 afin que cette boucle ne se reproduise pas 
                rospy.sleep(2) #On attends 2 sec 
    
              if self.cXJ is not None and self.cXJ > 100: #Si le moment de la ligne jaune est superieur a 100
    
                self.c += 1 #on compte
              
                if self.c < 10: #si le compte est inférieur a 10
    
                  cmd_vel.angular.z = -0.67 
                  cmd_vel.linear.x = 0.1
                  self.pub_cmd_vel.publish(cmd_vel) #On commande le robot pour qu'il aille au bon endroit
    
                if self.c == 10: #Si le compte est 10
                  cmd_vel.angular.z = -1 #On fait tourner le robot vers la suite du parcours
                  cmd_vel.linear.x = 0.0
                  self.pub_cmd_vel.publish(cmd_vel)
                  rospy.sleep(1.5) #attends 1.5 secondes
                  cmd_vel.angular.z = -0.0 #arrete de tourner
                  cmd_vel.linear.x = 0.0 #arrete d'avancer 
                  self.pub_cmd_vel.publish(cmd_vel)#Publier 
    
              if self.S is not None and self.S == 1:#Si on detecte un obstacle
    
                if self.cX is not None and self.cX != 0:#Si on detecte une ligne blanche
    
                  self.x += 1 #Compte le nombre d'obstacle rencontré
                  self.pub_ob.publish(self.x)#Publie
                  if self.x >= 3 and self.x < 5: #Si le nombre d'obstacle est 3 ou 4:
                    cmd_vel.angular.z = -1  # Set the angular velocity to 1 to make the robot turn 90 degrees
                    cmd_vel.linear.x = 0.0  # Set the linear velocity to 0.0 to prevent the robot from moving forward
                    self.pub_cmd_vel.publish(cmd_vel) #Publie
                    rospy.sleep(1.9) #Attend 1.9 seconde
                    cmd_vel.angular.z = 0.0  # Stop turning
                    cmd_vel.linear.x = 0.1 #Avance 
                    self.pub_cmd_vel.publish(cmd_vel)#Publier
                    rospy.sleep(2.3)  #Attendre 2.3 secondes
    
                  else:
                    cmd_vel.angular.z = 1  # Set the angular velocity to 0.9 to make the robot turn 90 degrees
                    cmd_vel.linear.x = 0.0  # Set the linear velocity to 0.0 to prevent the robot from moving forward
                    self.pub_cmd_vel.publish(cmd_vel)#publier
                    rospy.sleep(1.1)#attendre 1.1
                    cmd_vel.angular.z = 0.0  # Stop turning
                    self.pub_cmd_vel.publish(cmd_vel)#Publier
    
              else:#si aucune des conditions precedente:
    
                cmd_vel.linear.x = 0.1#Allez tout droit 
                self.pub_cmd_vel.publish(cmd_vel)#Publier 
                
            
                
            if self.compte==3: # Si il y a 3 lignes rouge detectée
                cmd_vel.angular.z = -1 # Set the angular velocity to 0.9 to make the robot turn 90 degrees
                cmd_vel.linear.x = 0.0  # Set the linear velocity to 0.0 to prevent the robot from moving forward
                self.pub_cmd_vel.publish(cmd_vel)#publier
                rospy.sleep(0.5)#attend 0.5 seconde
                if self.orientation_z==0.70: #Si le robot est orienté vers le bas
                    cmd_vel.angular.z = 0# Set the angular velocity to 0.9 to make the robot turn 90 degrees
                    cmd_vel.linear.x = 0.0  # Set the linear velocity to 0.0 to prevent the robot from moving forward
                    self.pub_cmd_vel.publish(cmd_vel)#publier 
                    
            rate.sleep()#Permet de respecter la fréquence
         
    
        


if __name__ == '__main__':
  rospy.init_node("Convert")
  my_node = ControlNode()
  my_node.start()