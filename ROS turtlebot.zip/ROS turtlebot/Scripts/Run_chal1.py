#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from geometry_msgs.msg import Twist, Point
from std_msgs.msg import Float64


class ControlNode(object):

  def __init__(self):
    # Params
    self.cX = None
    self.cY = None
    self.compte = 0

    # Subscribers
    rospy.Subscriber("point_coordinates", Point, self.callback)
    rospy.Subscriber("/compte", Float64, self.callback3)

    # Publishers
    self.pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

  def callback(self, msg):
    self.cX = msg.x#Recupere le moment des lignes blanches ou de la moyenne des lignes blanches et jaunes 
    self.cY = msg.y

  def callback3(self, msg):
    self.compte = msg.data#Recupere le nombre de ligne rouge detecté

  def start(self):
    rospy.loginfo("Starting control node")
    rate = rospy.Rate(10) #Frequence d'execution
    cmd_vel = Twist() #Creer un objet Twist
    while not rospy.is_shutdown():#Tant que le node ne s'arrete pas 
      if self.cX is not None and self.cY is not None:#Si on detecte une ligne blanche 
          
        if self.cX < 150:  # Point too much on the right
          cmd_vel.angular.z = 0.5 #tourne a gauche 
        elif self.cX > 165:  # Point too much on the left
          cmd_vel.angular.z = -0.6 #WTourne a droite
        else:
          cmd_vel.linear.x = 0.1 #sinon va tout droit 
          cmd_vel.angular.z = 0
      else:
        cmd_vel.linear.x = 0.1 #SI il detecte pas il va tout droit 
        cmd_vel.angular.z = 0

      self.pub_cmd_vel.publish(cmd_vel)#Publie

      if self.compte > 1:#Si le nombre de ligne rouge est superieur ou egale a 2
        rospy.signal_shutdown('Shutdown message') #Le node s'arrete

      rate.sleep()#Permet de respecter la frequence d'execution


if __name__ == '__main__':
  rospy.init_node("RUN")
  my_node = ControlNode()
  my_node.start()