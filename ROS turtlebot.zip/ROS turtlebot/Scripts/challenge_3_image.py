#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from geometry_msgs.msg import Point
from std_msgs.msg import String, Float64


class Nodo(object):

  def __init__(self):
    # Params
    self.image = None
    self.br = CvBridge()
    self.compte = 0
    self.last_time = 0
    
    # Publishers
    self.point_pub = rospy.Publisher('point_coor', Point, queue_size=10)#Publie les coordonnees des points 
  
    # Subscribers
    rospy.Subscriber("/compte", Float64, self.callback3) #Souscris au compte de ligne rouge depuis le challenge 2
    rospy.Subscriber("/camera/image", Image, self.callback) #Souscris a l'image de la camera du robot 

  def callback(self, msg):
    self.image = self.br.imgmsg_to_cv2(msg, desired_encoding="bgr8") #Recupere l'image
    
  def callback3(self,msg):
     self.compte=msg.data #Recupere le nombre de ligne rouge depuis le challenge 2

  def start(self):

    rate = rospy.Rate(10)  # création d'un objet Rate pour contrôler la fréquence d'exécution de la boucle principale
    while not rospy.is_shutdown(): # tant que le nœud ROS n'a pas reçu de commande d'arrêt
      if self.compte>3: #Si on a compté + de 3 lignes rouge
          if self.image is not None: # si une image a été reçue de la caméra
    
            hsv = cv2.cvtColor(self.image, cv2.COLOR_BGR2HSV)# Convertir l'image de la caméra en espace de couleurs HSV
            
             # Définir les bornes inférieure et supérieure pour la couleur verte
            lower_green = np.array([40, 50, 50])
            upper_green = np.array([80, 255, 255])
    
            # Créer un masque pour la couleur verte en utilisant les bornes inférieure et supérieure
            mask_green = cv2.inRange(hsv, lower_green, upper_green)
            
            # Calculer les moments du masque pour déterminer la position du centre de masse de la couleur verte
            M = cv2.moments(mask_green)
            
            # si la surface de la zone verte est supérieure à zéro
            if M["m00"] > 0:
              # Calculer la position du centre de masse en utilisant les moments calculés
              cX = int(M["m10"] / M["m00"])
              cY = int(M["m01"] / M["m00"])
              # Créer un message Point pour stocker la position du centre de masse de la couleur verte
              point_msg = Point()
              point_msg.x = cX
              point_msg.y = cY
              
              # Publier le message Point sur le topic /point_coor
             
              self.point_pub.publish(point_msg)

      rate.sleep() # attendre le temps nécessaire pour maintenir la fréquence d'exécution de la boucle principale


if __name__ == '__main__':
  rospy.init_node("OpenCV")
  my_node = Nodo()
  my_node.start()

