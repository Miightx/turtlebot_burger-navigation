#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from geometry_msgs.msg import Point
from std_msgs.msg import String, Float64


class Nodo(object):

  def __init__(self):
    # Params
    self.image = None
    self.br = CvBridge()
    self.compte = 0
    self.last_time = 0
    self.ob=0
    # Publishers
    
    self.point_pub = rospy.Publisher('point_coordinates', Point, queue_size=10)
    self.point = rospy.Publisher('point', Point, queue_size=10)
    self.c = rospy.Publisher('compte', Float64, queue_size=10)
    # Subscribers
    rospy.Subscriber("/camera/image", Image, self.callback)
    rospy.Subscriber("/obstacle", Float64, self.callback1)

    
  def callback(self, msg):    # Fonction de rappel pour la caméra
    self.image = self.br.imgmsg_to_cv2(msg, desired_encoding="bgr8")
    
  def callback1(self, msg):   # Fonction de rappel pour les obstacles
    self.ob=msg.data
    
    
  def start(self):

    rate = rospy.Rate(10) # fréquence de publication
    while not rospy.is_shutdown():
      if self.image is not None:  # s'il y a une image
        roi = self.image[200:240, 0:320] # définit la région d'intérêt pour les couleurs jaune et blanche
        roi2 = self.image[239:240, 0:320] # définit la région d'intérêt pour la couleur rouge

        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV) # conversion de l'image en HSV
        hsv2 = cv2.cvtColor(roi2, cv2.COLOR_BGR2HSV) # conversion de l'image en HSV

        lower_red = np.array([0, 100, 100]) # définit la valeur HSV minimale pour la couleur rouge
        upper_red = np.array([10, 255, 255]) # définit la valeur HSV maximale pour la couleur rouge

        lower_yellow = np.array([20, 100, 100]) # définit la valeur HSV minimale pour la couleur jaune
        upper_yellow = np.array([30, 255, 255]) # définit la valeur HSV maximale pour la couleur jaune

        lower_white = np.array([0, 0, 200]) # définit la valeur HSV minimale pour la couleur blanche
        upper_white = np.array([255, 30, 255]) # définit la valeur HSV maximale pour la couleur blanche

        # Créer des masques pour les couleurs jaune et blanche
        mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
        mask_white = cv2.inRange(hsv, lower_white, upper_white)
        mask_red = cv2.inRange(hsv2, lower_red, upper_red)
        
        
        M1 = cv2.moments(mask_yellow)
        M2 = cv2.moments(mask_white)
        
        if np.any(mask_red != 0): # si la zone rouge est détectée
          now = rospy.Time.now()
          now = now.to_sec()
          elapsed_time = now - self.last_time
          if elapsed_time > 10.0: # si le temps écoulé est supérieur à 10 secondes
            self.compte += 1 # incrémenter le compteur
          
            self.c.publish(self.compte) # publier le compteur sur le topic "compte"
            self.last_time = now
     
        L = []
        LY = []
        cX = 0
        cY = 0
        cX2 = 0
        cY2 = 0
        
        if M1["m00"] > 0: # Vérification si un contour jaune a été détecté
        # Calcul du centre de gravité du contour jaune détecté
          cX = int(M1["m10"] / M1["m00"]) # Coordonnée x du centre de gravité
          cY = int(M1["m01"] / M1["m00"]) # Coordonnée y du centre de gravité
          
           # Création d'un message contenant les coordonnées du centre de gravité du contour jaune détecté
          point_msg = Point()
          point_msg.x = cX
          point_msg.y = cY
          
            # Ajout des coordonnées x et y du centre de gravité du contour jaune à la liste L et LY respectivement
          L.append(cX)
          LY.append(cY)
          
           # Publication du message contenant les coordonnées du centre de gravité du contour jaune
          self.point.publish(point_msg)
          
          # Vérification si un contour blanc a été détecté
          
        if M2["m00"] > 0:
        # Calcul du centre de gravité du contour blanc détecté
            
          cX2 = int(M2["m10"] / M2["m00"])# Coordonnée x du centre de gravité
          cY2 = int(M2["m01"] / M2["m00"])# Coordonnée y du centre de gravité
          
          # Création d'un message contenant les coordonnées du centre de gravité du contour blanc détecté
          point_msg2 = Point()
          point_msg2.x = cX2
          point_msg2.y = cY2
          
            # Ajout des coordonnées x et y du centre de gravité du contour blanc à la liste L et LY respectivement
          L.append(cX2)
          LY.append(cY2)
         
        
# Vérification si le robot n'a pas encore effectué plus de 1 détection, que les coordonnées x des centres de gravité des
# contours jaune et blanc ne sont pas nulles et que la distance entre ces coordonnées est supérieure à 210
          
        if self.compte <= 1 and cX is not None and cX2 is not None and abs(cX - cX2) > 210 and self.ob!=3:
         # Création d'un message contenant les coordonnées du centre de gravité du contour blanc
          point_msg2 = Point()
          point_msg2.x = cX2
          point_msg2.y = cY2
          # Publication du message contenant les coordonnées du centre de gravité du contour blanc
          self.point_pub.publish(point_msg2)
          
# If both centroids have been found and list L is not empty and obstacle flag is not 3

        elif cX is not None and cX2 is not None and len(L) != 0 and self.ob!=3:
          #Calculate the mean of all x-coordinates and y-coordinates
          cX3 = np.mean(L)
          cY3 = np.mean(LY)
          #Create a Point message with the calculated mean x-coordinate and y-coordinate
          point_msg3 = Point()
          point_msg3.x = cX3
          point_msg3.y = cY3
          #Publish the Point message to the topic
          self.point_pub.publish(point_msg3)

# If there are already 2 detected objects and 4 or less objects have been detected and the distance between centroids is greater than 200 or
# one of the centroids is 0 or one of the centroids is None
        if self.compte > 1 and self.compte<4 and cX is not None and cX2 is not None and (abs(cX - cX2) > 200 or cX == 0 or cX is None):
         #Create a Point message with the x-coordinate shifted by 60 pixels to the left and the y-coordinate unchanged
          point_msg2 = Point()
          point_msg2.y = cY2
          point_msg2.x = cX2 - 60
          
         #Publish the Point message to the topic
          self.point_pub.publish(point_msg2)
          
       
        if self.ob>=3: #If there are 3 or more detected objects
            #Create a Point message with the x-coordinate shifted by 80 pixels to the left and the y-coordinate unchanged
       
          point_msg2 = Point()
          
          point_msg2.y = cY2
          point_msg2.x = cX2 - 80
          
          #Publish the Point message to the topic
          self.point_pub.publish(point_msg2)

      rate.sleep() #Wait for the specified amount of time


if __name__ == '__main__':
  rospy.init_node("OpenCV")
  my_node = Nodo()
  my_node.start()





   
