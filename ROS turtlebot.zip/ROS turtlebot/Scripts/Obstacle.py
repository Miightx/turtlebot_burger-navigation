#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float64


class CNodo(object):
    def __init__(self):
        # Params
        self.obs_f = None
        self.obs_l = None
        self.message = None
        self.compte=0

        # Subscribers
        rospy.Subscriber("/scan", LaserScan, self.callback)
        rospy.Subscriber("/compte", Float64, self.callback1)

        # Publishers
        self.p = rospy.Publisher('S', Float64, queue_size=10)


    def callback(self, msg):
        
        #On recupere les distances du laser
        
        self.obs_f = msg.ranges[330:360] 
        self.obs_l = msg.ranges[0:30]
        self.message = self.obs_f + self.obs_l
        
    def callback1(self, msg):
        self.compte=msg.data #On recupere le compte de ligne rouge

    def start(self):
        rospy.loginfo("Starting control node")
        rate = rospy.Rate(10)
    
        while not rospy.is_shutdown():
            if self.compte > 3:#Si 3 lignes rouge 
                S = 0 #On initialise S a 0
                if self.message is not None: #if le laser capte quelque chose devant lui
                    for distance in self.message: #Pour une distance dans le self.message
                        if distance < 0.2: #Si le capteur capte une distance inférieure a 0.2
                            S = 1 #S prend la valeur 1 
                            break #LA boucle se casse 
                self.p.publish(S) #On publie S dans le topic "S"

            rate.sleep() #Permet de bien respecter la fréquence

            
if __name__ == '__main__':
    rospy.init_node("Obstacle")
    my_node = CNodo()
    my_node.start()


