#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from geometry_msgs.msg import Point
from std_msgs.msg import String, Float64


class Nodo(object):

  def __init__(self):
    # Params
    self.image = None
    self.br = CvBridge()
    self.compte = 0
    self.last_time = 0
    self.ob=0
    
    # Publishers
    self.point_pub = rospy.Publisher('point_coordinates', Point, queue_size=10)
    self.c = rospy.Publisher('compte', Float64, queue_size=10)
    
    # Subscribers
    rospy.Subscriber("/camera/image", Image, self.callback)
    rospy.Subscriber("/obstacle", Float64, self.callback1)

  def callback(self, msg):

    self.image = self.br.imgmsg_to_cv2(msg, desired_encoding="bgr8") #Recupere l'image de la camera du robot
    
  def callback1(self, msg):

    self.ob=msg.data #Recupere ce nombre pour savoir si il y a un obstacle ou pas 
    
  def start(self):

    rate = rospy.Rate(10) #Frequence d'execution
    while not rospy.is_shutdown(): #tant que le node tourne
      if self.image is not None: #Si on a une image 
          
        roi = self.image[200:240, 0:320]#Definition d'une region d interet, ici, juste la partie basse de l'image
   

        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)#convertit l image en HSV
        
        # Définir les bornes pour la couleur rouge, jaune et blanche
        lower_red = np.array([0, 100, 100])#
        upper_red = np.array([10, 255, 255])


        lower_yellow = np.array([20, 100, 100])
        upper_yellow = np.array([30, 255, 255])

        lower_white = np.array([0, 0, 200])
        upper_white = np.array([255, 30, 255])

        # Créer des masques pour les couleurs jaune rouge et blanche
        mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
        mask_white = cv2.inRange(hsv, lower_white, upper_white)
        mask_red = cv2.inRange(hsv, lower_red, upper_red)
        
        #Calcul les moments des masques jaune et blanc
        M1 = cv2.moments(mask_yellow)
        M2 = cv2.moments(mask_white)
        
        #Compte le nombre de ligne rouge detecté, en attendant 12 secondes si une ligne a deja ete detectée
        if np.any(mask_red != 0):
          now = rospy.Time.now()
          now = now.to_sec()
          elapsed_time = now - self.last_time
          if elapsed_time > 12.0:
            self.compte += 1
            self.c.publish(self.compte)
            self.last_time = now

        # Initialisation des variables pour stocker les coordonnées X et Y de la ligne
        L = []
        LY = []
        cX = 0
        cY = 0
        cX2 = 0
        cY2 = 0
        
        if M1["m00"] > 0: # si le moment d'ordre 0 de la couleur jaune est supérieur à 0 (c'est-à-dire si la couleur jaune est détectée)
          cX = int(M1["m10"] / M1["m00"])# calcul du centre de masse en X de la couleur jaune
          cY = int(M1["m01"] / M1["m00"])# calcul du centre de masse en Y de la couleur jaune
          point_msg = Point() # création d'un message de type Point
          point_msg.x = cX # assignation de la coordonnée en X du centre de masse de la couleur jaune à la propriété y du message Point
          point_msg.y = cY # assignation de la coordonnée en Y du centre de masse de la couleur jaune à la propriété y du message Point
          L.append(cX)  # ajout de la coordonnée en X du centre de masse de la couleur jaune à la liste L
          LY.append(cY) # ajout de la coordonnée en Y du centre de masse de la couleur jaune à la liste LY


        if M2["m00"] > 0: # si le moment d'ordre 0 de la couleur blanche est supérieur à 0 (c'est-à-dire si la couleur blanche est détectée)
          cX2 = int(M2["m10"] / M2["m00"]) # calcul du centre de masse en X de la couleur blanche
          cY2 = int(M2["m01"] / M2["m00"]) # calcul du centre de masse en Y de la couleur blanche
          point_msg2 = Point() # création d'un message de type Point
          point_msg2.x = cX2 # assignation de la coordonnée en X du centre de masse de la couleur blanche à la propriété y du message Point
          point_msg2.y = cY2 # assignation de la coordonnée en Y du centre de masse de la couleur blanche à la propriété y du message Point
          L.append(cX2)  # ajout de la coordonnée en X du centre de masse de la couleur blanche à la liste L
          LY.append(cY2)  # ajout de la coordonnée en Y du centre de masse de la couleur blanche à la liste LY


        if cX is not None and cX2 is not None and len(L) != 0: # si les centres de masse de la couleur jaune et de la couleur blanche sont détectés et que la liste L n'est pas vide
 
          point_msg3 = Point() # création d'un message de type Point
          point_msg3.x = cX2-100 # assignation de la coordonnée en X du centre de masse de la couleur blanche (avec un décalage de 100 pixels) à la propriété x du message Point
          point_msg3.y = cY2 # assignation de la coordonnée en Y du centre de masse de la couleur blanche à la propriété y du message Point
          self.point_pub.publish(point_msg3)  # publication du message Point sur le topic 'point_pub'
         
        if self.compte>3: # si le compteur 'compte' est supérieur à 3
            rospy.signal_shutdown('Shutdown message') #Arret du node
      
             

      rate.sleep() # attendre le temps nécessaire pour maintenir la fréquence d'exécution de la boucle principale


if __name__ == '__main__':
  rospy.init_node("image_chal2")
  my_node = Nodo()
  my_node.start()
