# ROS Line Following Robot

![ROS PROJECT BOKOBZA Evan LIN Laurent]

The ROS PROJECT BOKOBZA Evan LIN Laurent is a software project that aims to complete a series of challenges related to navigation and obstacle avoidance using ROS (Robot Operating System). The project will require the design and implementation of a variety of nodes to achieve the project goals.

The challenges that the project aims to complete include line tracking, obstacle avoidance, wall avoidance to navigate through a corridor, and obstacle avoidance while traveling towards the exit. To complete these challenges, the project will require the use of a variety of ROS tools and techniques, as well as a solid understanding of ROS programming concepts.

The project will begin with the implementation of the line following nodes, which will be responsible for initiating the line tracking functionality and stopping the robot when it reaches the start of the corridor. 

Once the line following nodes has been successfully implemented, the project will move on to the implementation of the Wall Avoidance nodes. These nodes will allow the robot or vehicle to navigate through the corridor while avoiding walls. The Obstacle Avoidance node will be particularly important in the latter stages of the project, as it will be used to navigate towards the exit while avoiding obstacles.

Throughout the project, a variety of ROS tools and techniques will be used to develop and test the code. This may include using RViz to visualize the robot or vehicle's movements, using rostopic echo and rostopic pub to test and debug the code, and using rosrun to execute the nodes.

Successful completion of the project will require a solid understanding of ROS, as well as strong programming skills and a careful attention to detail. By successfully completing the challenges, the project team will demonstrate their ability to design and implement effective navigation and obstacle avoidance strategies using ROS


#INSTALLATION
```
Install ROS: The first step is to install ROS on your machine. You can find detailed instructions on how to do this on the ROS wiki (http://wiki.ros.org/Installation).

Create a catkin workspace: Once ROS is installed, you will need to create a catkin workspace. To do this, open a terminal window and type the following commands:

$ mkdir -p ~/catkin_ws/src
$ cd ~/catkin_ws/
$ catkin_make

This will create a catkin workspace in your home directory and build the necessary directories and files.

Download the project code: Download the project code and unzip the file to a location on your machine.

Copy the project files into the catkin workspace: Open a terminal window and type the following commands:

$ cd <project-folder>
$ cp -r . ~/catkin_ws/src/
This will copy the project files into the src directory of your catkin workspace.

Build the project: Once the project files have been copied into the catkin workspace, you will need to build the project. To do this, open a terminal window and type the following commands:

$ cd ~/catkin_ws/
$ catkin_make
This will build the project and create the necessary executable files.

Test the project: Finally, you will need to test the project to ensure that everything is working correctly. To do this, open a terminal window and type the following commands:

$ source ~/catkin_ws/devel/setup.bash
$ roslaunch <projet> <challenge1.launch>
$ roslaunch <projet> <challenge2_3.launch>
This will launch the project and allow you to test the various nodes and functionality.
```

Launch the ROS nodes: To start using the project, you will need to launch the ROS nodes that are included in the project. 

Test the nodes: Once the ROS nodes have been launched, you can test the various nodes.

Debugging: If you encounter any issues while using the project, you can use the ROS logging system to help you debug the problem. This can be done by opening a terminal window and typing the following command:

$ rostopic echo <topic-name>
This will display the messages being published to the specified topic and can help you identify any issues that may be occurring.

Shutdown the nodes: When you are finished using the project, you can shutdown the ROS nodes by pressing Ctrl+C in the terminal window where the nodes were launched.
```
Project contributors: Evan Bokobza, Laurent Lin
Project supervisor: [Fabien Vérité]
Project dependencies: ROS, OpenCV, Rospy, numpy, math, time

Project date: [27 mars-28 avril]
```

### Topics

- `/camera/image`: Publishes raw camera images
- `/usb_camera/image_raw : Publised raw real camera images
- `/cmd_vel`: A command to send velocity commands to a robot
- `/scan`: A detection of obstacles with LSD scan.
- `/compte`: A count of red line crossed.
- `/point_coordinates`: Get informations about the coordinates during the line detections.
- `/obstacle`: Published a message to avoid objects.
- `/point`: Get the gravity centre 
- `/S`: Publish obstacle warning
- `/point_coor`: Get the coordinate x and y of the LSD scan









